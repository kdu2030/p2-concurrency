To build, run the make command in the working directory.
To run the program, use ./run.sh